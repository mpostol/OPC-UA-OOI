﻿It is place holder of the configuration editor. Configuration editor is an assembly implementing 

CAS.UA.IServerConfiguration.IConfiguration

The definition is provided by the package:

<package id="CAS.UA.IServerConfiguration" version="1.00.00" targetFramework="net461" />

For example this interface is implemented by the class

UAOOI.Configuration.DataBindings.UANetworkingConfigurationEditor
